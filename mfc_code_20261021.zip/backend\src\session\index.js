// src/session/index.js
//
// Сессии пользователей — своя реализация на встроенном crypto Node
// (без express-session: во внутреннем npm-репозитории нет uid-safe и др.).
//   - кука: httpOnly, SameSite (по умолчанию Lax), Secure в production;
//     значение «s:<id>.<HMAC-SHA256>» — формат как у express-session;
//   - TTL «по бездействию» = Session@ttlMinutes (rolling: продлевается на
//     каждом ответе), абсолютный предел = Session@absoluteHours (requireAuth);
//   - req.session: данные + cookie{expires,maxAge} + regenerate/save/destroy/touch,
//     req.sessionID — как в express-session, остальной код не меняется;
//   - хранилище за интерфейсом Store (get/set/touch/destroy с callback,
//     совместим с connect-redis): store="memory" — встроенное с TTL
//     (один инстанс бэка); для нескольких — createApp({ sessionStore }).
//
// ВНИМАНИЕ: в сессии лежат OAuth-токены SAP пользователя. Внешнее хранилище
// (Redis и т.п.) должно быть закрыто (ACL/TLS), как хранилище секретов.

const crypto = require('crypto');

class TtlMemoryStore {
  constructor({ ttlMs, pruneIntervalMs = 60 * 1000, now = () => Date.now() } = {}) {
    this.ttlMs = ttlMs;
    this.now = now;
    this.sessions = new Map();
    this.timer = setInterval(() => this.prune(), pruneIntervalMs);
    this.timer.unref();
  }

  _expiry(sess) {
    const cookieExp = sess?.cookie?.expires ? new Date(sess.cookie.expires).getTime() : null;
    return cookieExp || this.now() + this.ttlMs;
  }

  prune() {
    const t = this.now();
    for (const [sid, e] of this.sessions) if (e.expiresAt <= t) this.sessions.delete(sid);
  }

  get(sid, cb) {
    const e = this.sessions.get(sid);
    if (!e) return cb(null, null);
    if (e.expiresAt <= this.now()) {
      this.sessions.delete(sid);
      return cb(null, null);
    }
    try { return cb(null, JSON.parse(e.json)); } catch (err) { return cb(err); }
  }

  set(sid, sess, cb) {
    this.sessions.set(sid, { json: JSON.stringify(sess), expiresAt: this._expiry(sess) });
    if (cb) cb(null);
  }

  touch(sid, sess, cb) {
    const e = this.sessions.get(sid);
    if (e) e.expiresAt = this._expiry(sess);
    if (cb) cb(null);
  }

  destroy(sid, cb) {
    this.sessions.delete(sid);
    if (cb) cb(null);
  }

  length(cb) { cb(null, this.sessions.size); }
  clear(cb) { this.sessions.clear(); if (cb) cb(null); }
  close() { clearInterval(this.timer); }
}

function createSessionStore(sessionConfig) {
  switch (sessionConfig.store) {
    case 'memory':
      return new TtlMemoryStore({ ttlMs: sessionConfig.ttlMinutes * 60 * 1000 });
    default:
      throw new Error(
        `Session@store="${sessionConfig.store}" не поддерживается встроенно. ` +
        'Используйте store="memory" или передайте внешний Store в createApp({ sessionStore }).'
      );
  }
}

// ── Подпись куки ────────────────────────────────────────────────────────────
function sign(id, secret) {
  return `s:${id}.${crypto.createHmac('sha256', secret).update(id).digest('base64').replace(/=+$/, '')}`;
}

function unsign(value, secret) {
  if (typeof value !== 'string' || !value.startsWith('s:')) return null;
  const body = value.slice(2);
  const dot = body.lastIndexOf('.');
  if (dot <= 0) return null;
  const id = body.slice(0, dot);
  const expected = Buffer.from(sign(id, secret));
  const actual = Buffer.from(value);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual) ? id : null;
}

function readCookie(header, name) {
  if (!header) return undefined;
  for (const part of String(header).split(';')) {
    const eq = part.indexOf('=');
    if (eq < 0) continue;
    if (part.slice(0, eq).trim() !== name) continue;
    const v = part.slice(eq + 1).trim();
    try { return decodeURIComponent(v); } catch { return v; }
  }
  return undefined;
}

function serializeCookie(name, value, opts) {
  const parts = [`${name}=${encodeURIComponent(value)}`, `Path=${opts.path || '/'}`];
  if (opts.expires) parts.push(`Expires=${opts.expires.toUTCString()}`);
  if (opts.httpOnly) parts.push('HttpOnly');
  if (opts.secure) parts.push('Secure');
  if (opts.sameSite) parts.push(`SameSite=${String(opts.sameSite).replace(/^./, (c) => c.toUpperCase())}`);
  return parts.join('; ');
}

function appendSetCookie(res, cookie) {
  const prev = res.getHeader('Set-Cookie');
  res.setHeader('Set-Cookie', prev ? [].concat(prev, cookie) : cookie);
}

const RESERVED = new Set(['cookie', 'id', 'regenerate', 'save', 'destroy', 'touch', 'reload']);

/** Объект req.session: поля данных + методы управления. */
function makeSession(req, ctl, id, data) {
  const s = Object.create({
    regenerate(cb) {
      ctl.store.destroy(req.sessionID, () => {
        const nid = crypto.randomBytes(24).toString('base64url');
        req.sessionID = nid;
        req.session = makeSession(req, ctl, nid, {});
        req.session.__isNew = true;
        if (cb) cb(null);
      });
    },
    save(cb) {
      ctl.store.set(req.sessionID, serialize(req.session), (e) => {
        if (!e) req.session.__saved = JSON.stringify(serialize(req.session));
        if (cb) cb(e || null);
      });
    },
    destroy(cb) {
      const sid = req.sessionID;
      req.session = null;
      ctl.store.destroy(sid, (e) => { if (cb) cb(e || null); });
    },
    touch() { this.cookie.expires = new Date(Date.now() + ctl.maxAge); },
    reload(cb) { if (cb) cb(null); },
  });
  Object.defineProperty(s, 'id', { value: id, enumerable: false, writable: true });
  Object.defineProperty(s, '__isNew', { value: false, enumerable: false, writable: true });
  Object.defineProperty(s, '__saved', { value: null, enumerable: false, writable: true });
  for (const [k, v] of Object.entries(data || {})) if (!RESERVED.has(k)) s[k] = v;
  s.cookie = { maxAge: ctl.maxAge, expires: new Date(Date.now() + ctl.maxAge) };
  Object.defineProperty(s, 'cookie', { enumerable: false, writable: true, value: s.cookie });
  return s;
}

function serialize(sess) {
  const out = { cookie: { expires: sess.cookie.expires, maxAge: sess.cookie.maxAge } };
  for (const k of Object.keys(sess)) out[k] = sess[k];
  return out;
}

function hasData(sess) {
  return Object.keys(sess).length > 0;
}

function createSessionMiddleware(sessionConfig, store) {
  const ctl = {
    store,
    name: sessionConfig.cookieName,
    secret: sessionConfig.secret,
    maxAge: sessionConfig.ttlMinutes * 60 * 1000,
    cookie: { httpOnly: true, secure: !!sessionConfig.secure, sameSite: sessionConfig.sameSite, path: '/' },
  };

  return function sessionMiddleware(req, res, next) {
    if (req.session) return next();

    // Secure-кука уходит только по HTTPS (за прокси — req.secure при TrustProxy)
    const canSetCookie = !ctl.cookie.secure || req.secure;

    // Кука пишется перед отправкой заголовков; данные сохраняются до res.end.
    const writeHead = res.writeHead;
    res.writeHead = function patchedWriteHead(...args) {
      const s = req.session;
      if (s && canSetCookie && hasData(s) && !res.headersSent) {
        s.touch();
        appendSetCookie(res, serializeCookie(ctl.name, sign(req.sessionID, ctl.secret), { ...ctl.cookie, expires: s.cookie.expires }));
      }
      return writeHead.apply(this, args);
    };

    const end = res.end;
    let ending = false;
    res.end = function patchedEnd(...args) {
      if (ending) return end.apply(this, args);
      ending = true;
      const s = req.session;
      const finish = () => end.apply(res, args);
      if (!s || !hasData(s)) return finish();
      const snapshot = JSON.stringify(serialize(s));
      if (snapshot !== s.__saved) return ctl.store.set(req.sessionID, serialize(s), () => finish());
      if (ctl.store.touch) return ctl.store.touch(req.sessionID, serialize(s), () => finish());
      return finish();
    };

    const sid = unsign(readCookie(req.headers.cookie, ctl.name), ctl.secret);
    const fresh = () => {
      req.sessionID = crypto.randomBytes(24).toString('base64url');
      req.session = makeSession(req, ctl, req.sessionID, {});
      req.session.__isNew = true;
      next();
    };
    if (!sid) return fresh();
    return ctl.store.get(sid, (err, data) => {
      if (err || !data) return fresh();
      req.sessionID = sid;
      req.session = makeSession(req, ctl, sid, data);
      req.session.__saved = JSON.stringify(serialize(req.session));
      return next();
    });
  };
}

module.exports = { createSessionStore, createSessionMiddleware, TtlMemoryStore, sign, unsign };
