// scripts/check-registry.js — какие пакеты бэка есть во внутреннем npm-репозитории.
//
// Запуск из папки бэка (PowerShell-скрипты на рабочих ПК запрещены политикой,
// поэтому на Node):
//   node scripts/check-registry.js
//
// Каждый пакет скачивается через сам npm (`npm cache add имя@версия`) — с теми же
// реестром, авторизацией и сертификатами, что у `npm install`. Ошибка 404 = пакета
// в репозитории нет. Отсутствующие сохраняются в missing-packages.txt.

const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

const GROUPS = {
  'ОБЯЗАТЕЛЬНЫЕ (без них бэк не установится)': [
    'accepts@1.3.8',
    'array-flatten@1.1.1',
    'asynckit@0.4.0',
    'axios@1.12.2',
    'body-parser@1.20.8',
    'bytes@3.1.2',
    'call-bind-apply-helpers@1.0.2',
    'call-bound@1.0.4',
    'combined-stream@1.0.8',
    'content-disposition@0.5.4',
    'content-type@1.0.5',
    'cookie-signature@1.0.7',
    'cookie@0.7.2',
    'cors@2.8.6',
    'debug@2.6.9',
    'delayed-stream@1.0.0',
    'depd@2.0.0',
    'destroy@1.2.0',
    'dotenv@16.6.1',
    'dunder-proto@1.0.1',
    'ee-first@1.1.1',
    'encodeurl@2.0.0',
    'es-define-property@1.0.1',
    'es-errors@1.3.0',
    'es-object-atoms@1.1.1',
    'es-set-tostringtag@2.1.0',
    'escape-html@1.0.3',
    'etag@1.8.1',
    'express@4.22.2',
    'finalhandler@1.3.2',
    'follow-redirects@1.15.11',
    'form-data@4.0.4',
    'forwarded@0.2.0',
    'fresh@0.5.2',
    'function-bind@1.1.2',
    'get-intrinsic@1.3.0',
    'get-proto@1.0.1',
    'gopd@1.2.0',
    'has-symbols@1.1.0',
    'has-tostringtag@1.0.2',
    'hasown@2.0.2',
    'http-errors@2.0.1',
    'iconv-lite@0.4.24',
    'inherits@2.0.4',
    'ipaddr.js@1.9.1',
    'math-intrinsics@1.1.0',
    'media-typer@0.3.0',
    'merge-descriptors@1.0.3',
    'methods@1.1.2',
    'mime-db@1.52.0',
    'mime-types@2.1.35',
    'mime@1.6.0',
    'ms@2.0.0',
    'ms@2.1.3',
    'negotiator@0.6.3',
    'object-assign@4.1.1',
    'object-inspect@1.13.4',
    'on-finished@2.4.1',
    'parseurl@1.3.3',
    'path-to-regexp@0.1.13',
    'proxy-addr@2.0.7',
    'proxy-from-env@1.1.0',
    'qs@6.15.3',
    'qs@6.16.0',
    'range-parser@1.2.1',
    'raw-body@2.5.3',
    'safe-buffer@5.2.1',
    'safer-buffer@2.1.2',
    'send@0.19.2',
    'serve-static@1.16.3',
    'setprototypeof@1.2.0',
    'side-channel-list@1.0.1',
    'side-channel-map@1.0.1',
    'side-channel-weakmap@1.0.2',
    'side-channel@1.1.1',
    'statuses@2.0.2',
    'toidentifier@1.0.1',
    'type-is@1.6.18',
    'unpipe@1.0.0',
    'utils-merge@1.0.1',
    'vary@1.1.2',
  ],
  'SSPI — вход через Windows (node-expose-sspi и его зависимости)': [
    '@jlguenego/asn.1@0.0.8',
    '@types/node-fetch@2.6.13',
    '@types/node@26.6.5',
    'asynckit@0.4.0',
    'call-bind-apply-helpers@1.0.2',
    'chevrotain@7.1.2',
    'combined-stream@1.0.8',
    'commander@6.2.1',
    'data-uri-to-buffer@3.0.1',
    'debug@4.4.3',
    'delayed-stream@1.0.0',
    'depd@1.1.2',
    'dunder-proto@1.0.1',
    'es-define-property@1.0.1',
    'es-errors@1.3.0',
    'es-object-atoms@1.1.2',
    'es-set-tostringtag@2.1.0',
    'fetch-blob@2.1.2',
    'form-data@4.0.6',
    'function-bind@1.1.2',
    'get-intrinsic@1.3.0',
    'get-proto@1.0.1',
    'gopd@1.2.0',
    'has-symbols@1.1.0',
    'has-tostringtag@1.0.2',
    'hasown@2.0.4',
    'http-errors@1.8.1',
    'inherits@2.0.4',
    'math-intrinsics@1.1.0',
    'mime-db@1.52.0',
    'mime-types@2.1.35',
    'ms@2.1.3',
    'node-expose-sspi@0.1.60',
    'node-fetch@3.0.0-beta.9',
    'ntlm-parser@1.0.9',
    'regexp-to-ast@0.5.0',
    'setprototypeof@1.2.0',
    'statuses@1.5.0',
    'toidentifier@1.0.1',
    'undici-types@8.9.0',
  ],
  'SAML / OAuth — понадобятся для ADFS (сейчас не нужны)': [
    '@node-saml/node-saml@5.1.0',
    '@types/debug@4.1.13',
    '@types/ms@2.1.0',
    '@types/node@26.6.5',
    '@types/qs@6.15.1',
    '@types/xml-encryption@1.2.4',
    '@types/xml2js@0.4.14',
    '@xmldom/is-dom-node@1.0.1',
    '@xmldom/xmldom@0.8.15',
    'debug@4.4.3',
    'ms@2.1.3',
    'sax@1.6.1',
    'undici-types@8.9.0',
    'xml-crypto@6.3.3',
    'xml-encryption@3.1.0',
    'xml2js@0.6.2',
    'xmlbuilder@11.0.1',
    'xmlbuilder@15.1.1',
    'xpath@0.0.32',
    'xpath@0.0.33',
    'xpath@0.0.34',
  ],
};

const PARALLEL = 6;
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';

function check(spec) {
  return new Promise((resolve) => {
    execFile(npm, ['cache', 'add', spec, '--no-audit', '--no-fund'],
      { shell: process.platform === 'win32', timeout: 120000, windowsHide: true },
      (err, stdout, stderr) => {
        if (!err) return resolve({ spec, ok: true });
        const out = String(stderr || stdout || err.message);
        const code = /E404|404 Not Found/i.test(out) ? '404'
          : /ETARGET|notarget/i.test(out) ? 'нет такой версии'
          : /E401|E403|401|403/.test(out) ? 'нет доступа'
            : /ETIMEDOUT|ECONNREFUSED|ENOTFOUND|EAI_AGAIN/.test(out) ? 'сеть'
              : 'ошибка';
        const line = out.split(/\r?\n/).find((l) => /npm (error|ERR!)/.test(l) && !/A complete log/.test(l)) || '';
        return resolve({ spec, ok: false, code, detail: line.trim() });
      });
  });
}

async function runPool(items, fn, n) {
  const results = new Array(items.length);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (next < items.length) {
      const i = next++;
      results[i] = await fn(items[i]);
      process.stdout.write('.');
    }
  }));
  process.stdout.write('\n');
  return results;
}

(async () => {
  const registry = await new Promise((r) => execFile(npm, ['config', 'get', 'registry'],
    { shell: process.platform === 'win32' }, (e, out) => r(String(out || '').trim())));
  console.log(`Реестр: ${registry}`);

  const missing = new Set();
  for (const [group, list] of Object.entries(GROUPS)) {
    console.log(`\n=== ${group} (${list.length}) ===`);
    const res = await runPool(list, check, PARALLEL);
    const bad = res.filter((r) => !r.ok);
    for (const r of bad) {
      console.log(`  НЕТ  ${r.spec}  (${r.code})${r.detail ? '  ' + r.detail : ''}`);
      missing.add(r.spec);
    }
    console.log(bad.length ? `  отсутствуют: ${bad.length} из ${list.length}` : '  все есть');
  }

  const all = [...missing].sort();
  console.log(`\n=== ИТОГ: отсутствуют ${all.length} ===`);
  for (const s of all) console.log(`  ${s}`);
  if (all.length) {
    const file = path.join(process.cwd(), 'missing-packages.txt');
    fs.writeFileSync(file, all.join('\r\n') + '\r\n');
    console.log(`Список сохранён в ${file} — его можно отдать администраторам репозитория.`);
  }
})();
