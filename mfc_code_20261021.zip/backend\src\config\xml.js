// src/config/xml.js
//
// Минимальный XML-парсер для конфигурации (sso-config.xml) и метаданных IdP.
// Свой, без @xmldom/xmldom: во внутреннем npm-репозитории нужных пакетов может
// не быть, а для конфига хватает подмножества XML:
//   элементы, атрибуты ("…" / '…'), текст, CDATA, комментарии, <?xml …?>,
//   сущности &amp; &lt; &gt; &quot; &apos; &#N; &#xN;.
// DOCTYPE запрещён (защита от XXE / «billion laughs»).
// Узлы повторяют нужную часть DOM-API: documentElement, firstChild,
// nextSibling, nodeType, nodeName, localName, hasAttribute, getAttribute,
// textContent. Работаем по local-name (без префиксов пространств имён),
// чтобы одинаково читать <md:EntityDescriptor> и <EntityDescriptor>.

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };

function decodeEntities(s, fail) {
  return s.replace(/&(#x[0-9a-fA-F]+|#\d+|[a-zA-Z]+);?/g, (m, e, off, all) => {
    if (!m.endsWith(';')) fail(`неэкранированный символ '&' (позиция ${off})`);
    if (e[0] === '#') {
      const code = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) fail(`некорректная ссылка на символ ${m}`);
      return String.fromCodePoint(code);
    }
    if (!(e in ENTITIES)) fail(`неизвестная сущность ${m}`);
    return ENTITIES[e];
  });
}

class XmlNode {
  constructor(nodeType, nodeName) {
    this.nodeType = nodeType; // 1 — элемент, 3 — текст
    this.nodeName = nodeName;
    this.localName = nodeType === 1 ? String(nodeName).replace(/^.*:/, '') : null;
    this.attrs = new Map();
    this.childNodes = [];
    this.firstChild = null;
    this.nextSibling = null;
    this.data = '';
  }

  hasAttribute(name) { return this.attrs.has(name); }
  getAttribute(name) { return this.attrs.has(name) ? this.attrs.get(name) : null; }

  get textContent() {
    if (this.nodeType === 3) return this.data;
    return this.childNodes.map((n) => n.textContent).join('');
  }

  _append(node) {
    const last = this.childNodes[this.childNodes.length - 1];
    if (last) last.nextSibling = node; else this.firstChild = node;
    this.childNodes.push(node);
  }
}

const NAME = /^[A-Za-z_][\w.:-]*/;

function parseDocument(src) {
  const fail = (msg) => { throw new Error(msg); };
  let i = 0;
  const doc = { documentElement: null };
  const stack = [];

  const lineAt = (pos) => src.slice(0, pos).split('\n').length;
  const text = (s) => {
    const parent = stack[stack.length - 1];
    if (!parent) {
      if (s.trim()) fail(`текст вне корневого элемента (строка ${lineAt(i)})`);
      return;
    }
    const n = new XmlNode(3, '#text');
    n.data = s;
    parent._append(n);
  };

  if (src.charCodeAt(0) === 0xfeff) i = 1; // BOM
  while (i < src.length) {
    const lt = src.indexOf('<', i);
    if (lt < 0) { text(decodeEntities(src.slice(i), fail)); break; }
    if (lt > i) text(decodeEntities(src.slice(i, lt), fail));
    i = lt;

    if (src.startsWith('<!--', i)) {
      const end = src.indexOf('-->', i + 4);
      if (end < 0) fail(`незакрытый комментарий (строка ${lineAt(i)})`);
      i = end + 3;
    } else if (src.startsWith('<![CDATA[', i)) {
      const end = src.indexOf(']]>', i + 9);
      if (end < 0) fail(`незакрытый CDATA (строка ${lineAt(i)})`);
      text(src.slice(i + 9, end));
      i = end + 3;
    } else if (src.startsWith('<?', i)) {
      const end = src.indexOf('?>', i + 2);
      if (end < 0) fail(`незакрытая инструкция <?…?> (строка ${lineAt(i)})`);
      i = end + 2;
    } else if (src.startsWith('<!', i)) {
      fail(`DOCTYPE и объявления <!…> не поддерживаются (строка ${lineAt(i)})`);
    } else if (src.startsWith('</', i)) {
      const m = NAME.exec(src.slice(i + 2));
      if (!m) fail(`некорректный закрывающий тег (строка ${lineAt(i)})`);
      const name = m[0];
      const gt = src.indexOf('>', i);
      if (gt < 0 || src.slice(i + 2 + name.length, gt).trim()) fail(`некорректный закрывающий тег </${name}> (строка ${lineAt(i)})`);
      const open = stack.pop();
      if (!open || open.nodeName !== name) {
        fail(`закрывающий тег </${name}> не соответствует открывающему ${open ? `<${open.nodeName}>` : ''} (строка ${lineAt(i)})`);
      }
      i = gt + 1;
    } else {
      // открывающий тег
      const m = NAME.exec(src.slice(i + 1));
      if (!m) fail(`некорректный тег (строка ${lineAt(i)})`);
      const el = new XmlNode(1, m[0]);
      i += 1 + m[0].length;
      let selfClosing = false;
      for (;;) {
        const ws = /^\s*/.exec(src.slice(i))[0];
        i += ws.length;
        if (src.startsWith('/>', i)) { selfClosing = true; i += 2; break; }
        if (src[i] === '>') { i += 1; break; }
        if (i >= src.length) fail(`незакрытый тег <${el.nodeName}>`);
        if (!ws) fail(`ожидался пробел перед атрибутом в <${el.nodeName}> (строка ${lineAt(i)})`);
        const an = NAME.exec(src.slice(i));
        if (!an) fail(`некорректный атрибут в <${el.nodeName}> (строка ${lineAt(i)})`);
        i += an[0].length;
        const eq = /^\s*=\s*/.exec(src.slice(i));
        if (!eq) fail(`атрибут ${an[0]} без значения в <${el.nodeName}> (строка ${lineAt(i)})`);
        i += eq[0].length;
        const q = src[i];
        if (q !== '"' && q !== "'") fail(`значение атрибута ${an[0]} должно быть в кавычках (строка ${lineAt(i)})`);
        const end = src.indexOf(q, i + 1);
        if (end < 0) fail(`незакрытое значение атрибута ${an[0]} (строка ${lineAt(i)})`);
        const raw = src.slice(i + 1, end);
        if (raw.includes('<')) fail(`символ '<' в значении атрибута ${an[0]} (строка ${lineAt(i)})`);
        if (el.attrs.has(an[0])) fail(`атрибут ${an[0]} повторяется в <${el.nodeName}>`);
        el.attrs.set(an[0], decodeEntities(raw, fail));
        i = end + 1;
      }
      const parent = stack[stack.length - 1];
      if (parent) parent._append(el);
      else if (doc.documentElement) fail('в документе больше одного корневого элемента');
      else doc.documentElement = el;
      if (!selfClosing) stack.push(el);
    }
  }
  if (stack.length) fail(`не закрыт тег <${stack[stack.length - 1].nodeName}>`);
  if (!doc.documentElement) fail('пустой документ');
  return doc;
}

function parseXml(input, sourceName = 'XML') {
  try {
    return parseDocument(String(input));
  } catch (e) {
    const err = new Error(`${sourceName}: некорректный XML — ${e.message}`);
    err.xmlErrors = [e.message];
    throw err;
  }
}

function localName(node) {
  return node.localName || String(node.nodeName).replace(/^.*:/, '');
}

/** Дочерние элементы (только непосредственные) с заданным local-name. */
function children(el, name) {
  const out = [];
  if (!el) return out;
  for (let n = el.firstChild; n; n = n.nextSibling) {
    if (n.nodeType === 1 && (!name || localName(n) === name)) out.push(n);
  }
  return out;
}

function child(el, name) {
  return children(el, name)[0] || null;
}

/** Все потомки с заданным local-name (обход в глубину). */
function descendants(el, name) {
  const out = [];
  const walk = (node) => {
    for (let n = node.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 1) {
        if (localName(n) === name) out.push(n);
        walk(n);
      }
    }
  };
  if (el) walk(el);
  return out;
}

function attr(el, name) {
  if (!el || !el.hasAttribute(name)) return undefined;
  return el.getAttribute(name);
}

function text(el) {
  if (!el) return undefined;
  return String(el.textContent || '').trim();
}

module.exports = { parseXml, children, child, descendants, attr, text, localName };
