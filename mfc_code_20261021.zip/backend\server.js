// server.js v5.0.0 — точка входа (npm start)
//
// v5.0.0: ПОЛНАЯ ПЕРЕРАБОТКА АВТОРИЗАЦИИ.
//   Было (v4.5.0): один глобальный SAP-клиент процесса (SPNEGO процесса Node
//   или логин/пароль из .env / консоли) — все пользователи видели данные
//   одного человека, кэш был общий.
//   Стало: SSO через IdP (ADFS + Kerberos/WIA) по SAML2 → сессия пользователя →
//   SAML2 Bearer Assertion → OAuth-токен SAP ЭТОГО пользователя → OData с
//   Authorization: Bearer. Каждый пользователь работает со своими ролями PFCG.
//   Подробности: AUTH_CONTRACT.md, docs/SSO-SETUP.md, README.md.
//
// Конфигурация: config/sso-config.xml (env SSO_CONFIG), секреты — через ${ENV}
// (можно положить в .env рядом с server.js).

require('dotenv').config();

const { loadConfig, ConfigError } = require('./src/config/loadConfig');
const { createApp } = require('./src/app');
const { createLogger } = require('./src/logger');

const log = createLogger('server');

function main() {
  let config;
  try {
    config = loadConfig();
  } catch (e) {
    if (e instanceof ConfigError) {
      console.error('\n' + e.message + '\n');
      for (const w of e.warnings || []) console.error(`  (предупреждение) ${w}`);
      console.error('Сервер не запущен. Описание формата: config/sso-config.example.xml\n');
    } else {
      console.error('Ошибка загрузки конфигурации:', e.message);
    }
    process.exit(1);
  }
  for (const w of config.warnings) log.warn(w);

  const { app, services } = createApp({ config });
  const port = Number(process.env.PORT) || 3001;
  const host = process.env.HOST || undefined;

  const server = app.listen(port, host, () => {
    const sys = config.getSystem();
    log.info(`SAP OData Backend v${require('./package.json').version} слушает порт ${port}`);
    log.info('конфигурация', {
      config: config.configPath,
      system: `${sys.id} (${sys.baseUrl}, sap-client ${sys.sapClient})`,
      sp: config.serviceProvider.entityId,
      idp: config.devMode.identity === 'windows' ? 'Windows (Negotiate/SSPI)'
        : config.devMode.mockIdp ? 'DEV mock-IdP' : config.identityProvider.entityId,
      sap: config.devMode.mockSap ? 'DEV mock SAP'
        : config.devMode.sap === 'spnego' ? 'Kerberos (SPNEGO) от учётки процесса' : 'SAML2 Bearer → OAuth2',
      origins: config.security.allowedOrigins.join(','),
    });
    // Сертификат SAP выдан корпоративным CA: Node доверяет ему только с
    // --use-system-ca (хранилище Windows) или с caFile в <SapSystem>.
    const systemCa = process.execArgv.includes('--use-system-ca') ||
      String(process.env.NODE_OPTIONS || '').includes('--use-system-ca');
    if (!config.devMode.mockSap && !systemCa && !sys.caPem && sys.rejectUnauthorized !== false) {
      log.warn('Node запущен без --use-system-ca и без caFile — запросы в SAP могут падать с ' +
        'UNABLE_TO_GET_ISSUER_CERT_LOCALLY. Запускайте: npm start (или npm run start:windows)');
    }
    if (config.devMode.enabled) {
      log.warn('DevMode ВКЛЮЧЁН — только для локальной разработки. Вход: ' +
        `${config.serviceProvider.publicBaseUrl}/auth/login`);
    }
    if (config.devMode.sap === 'spnego') checkSapConnection(config, services, sys);
  });

  const shutdown = (sig) => {
    log.info(`получен ${sig}, завершаем работу`);
    server.close(() => {
      services.sessionStore.close?.();
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

/**
 * DevMode sap="spnego": бэк ходит в SAP Kerberos-тикетом своей учётки, поэтому
 * связь можно проверить сразу при старте — не дожидаясь входа через фронт.
 * Пишет в лог «SAP доступен» или конкретную причину (сертификат, Kerberos, сеть).
 */
async function checkSapConnection(config, services, sys) {
  const started = Date.now();
  const sap = services.getSapClient(sys.id);
  try {
    const res = await sap.request(
      { auth: { sapUser: 'STARTUP-CHECK', tokens: {}, sap: {} }, sessionKey: 'startup' },
      { method: 'GET', path: '/$metadata', raw: true },
    );
    log.info(`✓ SAP доступен: ${sys.id} ${sys.baseUrl} (HTTP ${res.status}, ${Date.now() - started} мс, мандант ${sys.sapClient})`);
  } catch (e) {
    const msg = String(e.message || e);
    let hint = '';
    if (/CERT|certificate|self.signed/i.test(msg)) hint = 'сертификат SAP не доверен — запускайте npm start (node --use-system-ca) или укажите caFile';
    else if (/NTLM|Kerberos|SPNEGO/i.test(msg)) hint = 'нет Kerberos-тикета для SAP — ПК должен быть в домене, бэк запущен под доменной учёткой';
    else if (/ENOTFOUND|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN|ECONNRESET/i.test(msg)) hint = 'нет сетевого доступа к SAP с этого ПК';
    else if (e.code === 'sap_auth_redirect' || e.code === 'sap_login_page' || e.status === 401) hint = 'SAP не принял Kerberos-вход бэка';
    log.error(`✖ SAP НЕДОСТУПЕН: ${sys.id} ${sys.baseUrl} — ${msg}${hint ? ` → ${hint}` : ''}`);
  }
}

main();
