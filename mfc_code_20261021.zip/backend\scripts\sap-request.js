// scripts/sap-request.js — запрос в SAP OData прямо из бэка, без браузера и входа.
//
// Тот же код и та же авторизация, что у сервера (config/sso-config.xml):
//   sap="spnego" — Kerberos-тикет Windows-учётки, под которой запущен скрипт.
// Печатает полный URL запроса в SAP, статус, время и данные.
//
// Запуск из папки бэка:
//   npm run sap -- TaskSet '$top=5'
//   npm run sap -- TaskStageSet
//   npm run sap -- "TaskSet('0000012345')"
//   npm run sap -- UserInfoSet
// или напрямую:
//   node --use-system-ca scripts/sap-request.js TaskSet '$top=5&$filter=StageId eq 3'
//
// В PowerShell параметры с $ берите в ОДИНАРНЫЕ кавычки: '$top=5'.
// Если параметров несколько (есть &) — только прямой вызов node, не npm run:
// npm на Windows передаёт аргументы через cmd, а там & — разделитель команд.
// Другая система: $env:SAP_SYSTEM="S4Q"; npm run sap -- TaskSet '$top=5'
// Полный ответ без сокращения: $env:SAP_FULL="1"

const { loadConfig, detectSystem } = require('../src/config/loadConfig');
const { createLogger } = require('../src/logger');
const { SapODataClient } = require('../src/sap/sapClient');
const { SapTokenService, MockTokenService, SpnegoTokenService } = require('../src/auth/tokenService');

const [, , rawPath, rawQuery = ''] = process.argv;
if (!rawPath || rawPath === '-h' || rawPath === '--help') {
  console.log("Использование: npm run sap -- EntitySet ['$top=5&$filter=...']");
  console.log("Пример:        npm run sap -- TaskSet '$top=5'");
  process.exit(rawPath ? 0 : 1);
}

(async () => {
  const config = loadConfig();
  const log = createLogger('sap-request');
  const det = detectSystem(config, null, {});
  const system = config.getSystem(det.id);
  const mode = config.devMode.enabled ? config.devMode.sap : 'oauth';

  let tokenService;
  if (mode === 'spnego') tokenService = new SpnegoTokenService({ logger: log, spn: config.devMode.spn });
  else if (mode === 'mock') tokenService = new MockTokenService();
  else tokenService = new SapTokenService({ config, logger: log });

  let user = process.env.SAP_USER || '';
  if (!user && process.platform === 'win32') {
    try { user = require('../src/auth/windowsSspi').processUser().name; } catch { /* нет SSPI */ }
  }
  user = String(user || process.env.USERNAME || 'CLI').toUpperCase();

  const sap = new SapODataClient({ system, tokenService, logger: log });
  const path = rawPath.startsWith('/') ? rawPath : `/${rawPath}`;
  const query = [...new URLSearchParams(rawQuery.replace(/^\?/, ''))];
  if (!query.some(([k]) => k === '$format')) query.push(['$format', 'json']);

  console.log(`Система:  ${system.id} (выбрана: ${det.source}), мандант ${system.sapClient}, режим ${mode}`);
  console.log(`Учётка:   ${user}`);
  console.log(`→ GET     ${sap.buildUrl(path, query)}`);

  const started = Date.now();
  try {
    const res = await sap.request({ auth: { sapUser: user, tokens: {}, sap: {} }, sessionKey: 'cli' }, { method: 'GET', path, query });
    console.log(`← ${res.status}     за ${Date.now() - started} мс`);
    const d = res.data?.d;
    const rows = Array.isArray(d?.results) ? d.results : null;
    if (rows) {
      console.log(`Записей:  ${rows.length}${d.__count !== undefined ? ` (всего ${d.__count})` : ''}`);
      const show = process.env.SAP_FULL ? rows : rows.slice(0, 3);
      console.log(JSON.stringify(show.map(stripMeta), null, 2));
      if (show.length < rows.length) console.log(`… ещё ${rows.length - show.length} (полностью: $env:SAP_FULL="1")`);
    } else {
      const body = typeof res.data === 'string' ? res.data : JSON.stringify(stripMeta(d ?? res.data), null, 2);
      console.log(process.env.SAP_FULL ? body : String(body).slice(0, 4000));
    }
  } catch (e) {
    console.log(`✖ ОШИБКА за ${Date.now() - started} мс: ${e.code || ''} (HTTP ${e.status || '-'})`);
    console.log(`  ${e.message}`);
    if (e.sapMessage) console.log(`  SAP: ${e.sapMessage}`);
    if (e.location) console.log(`  Перенаправление на: ${e.location}`);
    if (e.code === 'sap_auth_redirect' || e.code === 'sap_login_page') {
      console.log('  → SAP не принял Kerberos-вход бэка. Браузер проходит этот шаг своим SSO,');
      console.log('    поэтому в нём данные есть. Пришлите этот вывод — по адресу перенаправления');
      console.log('    видно, какой способ входа SAP ожидает.');
    }
    process.exitCode = 1;
  }
})().catch((e) => {
  console.error(e.message);
  process.exitCode = 1;
});

function stripMeta(o) {
  if (!o || typeof o !== 'object') return o;
  const { __metadata, ...rest } = o; // eslint-disable-line no-unused-vars
  for (const [k, v] of Object.entries(rest)) {
    if (v && typeof v === 'object' && v.__deferred) delete rest[k];
  }
  return rest;
}
