// eslint.config.cjs — ESLint для бэка (Node.js, CommonJS).
//
// Без него VS Code применял к бэку правила фронта (браузер, ES-модули)
// и подсвечивал «'require' is not defined» / «'module' is not defined».
// Внешних пакетов (globals, @eslint/js) не требует — работает с любым ESLint 9.

const nodeGlobals = Object.fromEntries([
  'require', 'module', 'exports', '__dirname', '__filename', 'process', 'Buffer', 'console',
  'global', 'globalThis', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval',
  'setImmediate', 'clearImmediate', 'queueMicrotask', 'URL', 'URLSearchParams',
  'TextEncoder', 'TextDecoder', 'AbortController', 'fetch', 'structuredClone',
].map((g) => [g, 'readonly']));

module.exports = [
  { ignores: ['node_modules/**', 'keys/**'] },
  {
    files: ['**/*.js', '**/*.cjs'],
    linterOptions: { reportUnusedDisableDirectives: 'off' },
    languageOptions: {
      ecmaVersion: 'latest',
      sourceType: 'commonjs',
      globals: nodeGlobals,
    },
    rules: {
      'no-undef': 'error',
      'no-unused-vars': ['warn', { args: 'none', caughtErrors: 'none' }],
    },
  },
];
